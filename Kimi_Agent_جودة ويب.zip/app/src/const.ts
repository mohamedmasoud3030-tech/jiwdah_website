export const WHATSAPP_NUMBER = "968XXXXXXXX";
export const LOGIN_PATH = "/login";

export const NAV_LINKS = [
  { label: "الرئيسية", href: "/" },
  { label: "الخدمات", href: "/services" },
  { label: "الأعمال", href: "/portfolio" },
  { label: "من نحن", href: "/about" },
  { label: "تواصل معنا", href: "/contact" },
];

export const SERVICES = [
  {
    id: "wedding",
    title: "ضيافة حفلات الزفاف",
    description: "نقدم لك ضيافة زفاف كاملة تشمل القهوة العربية، البوفيه المفتوح، وطاقم خدمة مدرب لضيافة لا تُنسى.",
    price: "٣٠٠",
    image: "/images/service-wedding.jpg",
    icon: "Heart",
  },
  {
    id: "engagement",
    title: "ضيافة الملكات (الخطوبة)",
    description: "ضيافة مخصصة لمناسبات الخطوبة والملكات، تشمل تقديم القهوة العربية والتمور والحلويات التقليدية.",
    price: "٢٥٠",
    image: "/images/service-engagement.jpg",
    icon: "Gem",
  },
  {
    id: "conference",
    title: "ضيافة المؤتمرات والمعارض",
    description: "خدمات ضيافة احترافية للمؤتمرات والمعارض تشمل الضيافة الخفيفة، الوجبات، والقهوة.",
    price: "٤٠٠",
    image: "/images/service-conference.jpg",
    icon: "Users",
  },
  {
    id: "events",
    title: "تنظيم المناسبات الخاصة",
    description: "ننظم لك مناسبتك الخاصة من الألف إلى الياء مع ضيافة متكاملة وتنسيق ديكور وطاقم خدمة.",
    price: "٥٠٠",
    image: "/images/service-events.jpg",
    icon: "Calendar",
  },
  {
    id: "corporate",
    title: "ضيافة الشركات والفعاليات الرسمية",
    description: "ضيافة راقية للفعاليات الرسمية والشركات تشمل بوفيه كامل وخدمة VIP.",
    price: "٤٥٠",
    image: "/images/service-corporate.jpg",
    icon: "Building2",
  },
  {
    id: "coffee",
    title: "تقديم القهوة العربية",
    description: "خدمة تقديم القهوة العربية والتمور التقليدية مع قهوجي محترف لجميع المناسبات.",
    price: "١٥٠",
    image: "/images/service-coffee.jpg",
    icon: "Coffee",
  },
  {
    id: "buffet",
    title: "بوفيه مفتوح (ساخن/بارد)",
    description: "بوفيه مفتوح متكامل مع تشكيلة واسعة من الأطباق الساخنة والباردة مع طاقم تقديم.",
    price: "٣٥٠",
    image: "/images/service-buffet.jpg",
    icon: "UtensilsCrossed",
  },
  {
    id: "dinner",
    title: "تقديم وجبات (غداء/عشاء)",
    description: "خدمة تقديم وجبات غداء أو عشاء كاملة للمناسبات والمجموعات.",
    price: "٢٠٠",
    image: "/images/service-dinner.jpg",
    icon: "Clock",
  },
  {
    id: "vip",
    title: "ضيافة VIP",
    description: "أرقى مستويات الضيافة مع خدمة شخصية، تشكيلة مميزة من المأكولات، وطاقم مخصص.",
    price: "٦٠٠",
    image: "/images/service-vip.jpg",
    icon: "Crown",
  },
  {
    id: "tables",
    title: "تنظيم طاولات الضيافة",
    description: "تنسيق وتنظيم طاولات الضيافة بشكل احترافي مع ديكورات أنيقة وتفاصيل مبتكرة.",
    price: "١٨٠",
    image: "/images/portfolio-3.jpg",
    icon: "LayoutGrid",
  },
  {
    id: "staff",
    title: "توفير طاقم ضيافة مدرب",
    description: "نوفر لك طاقم ضيافة مدرب ومحترف لإدارة خدمات الضيافة في مناسبتك.",
    price: "٢٠٠",
    image: "/images/team.jpg",
    icon: "UserCheck",
  },
  {
    id: "mobile",
    title: "خدمة الضيافة المتنقلة",
    description: "نصلك أينما كنت في سلطنة عمان مع خدمة ضيافة متنقلة كاملة.",
    price: "٢٥٠",
    image: "/images/service-mobile.jpg",
    icon: "Truck",
  },
];

export const TESTIMONIALS = [
  {
    id: 1,
    name: "عائلة السيد أحمد",
    text: "خدمة رائعة، طاقم محترف وأكل لذيذ. أنصح الجميع بجودة الانطلاقة. شكراً على جهدكم المتميز في حفل زفاف ابنتنا.",
    rating: 5,
    service: "ضيافة زفاف",
  },
  {
    id: 2,
    name: "شركة النور للاستثمار",
    text: "تعاملنا معهم في أكثر من فعالية، والنتيجة دائماً ممتازة. خدمة احترافية وطاقم منظم. شراكة نفتخر بها.",
    rating: 5,
    service: "ضيافة شركات",
  },
  {
    id: 3,
    name: "سارة العامري",
    text: "ضيافة زفافي كانت مثالية، شكراً لكم على جهودكم. كل الضيوف أثنوا على جودة الطعام وأناقة التقديم.",
    rating: 5,
    service: "ضيافة زفاف",
  },
  {
    id: 4,
    name: "خالد البلوشي",
    text: "خدمة القهوة العربية في ملكة ابنتي كانت على أعلى مستوى. القهوجي محترف والتمور فاخرة. شكراً لكم.",
    rating: 5,
    service: "ضيافة ملكات",
  },
  {
    id: 5,
    name: "مؤسسة الرؤية",
    text: "نظمنا مؤتمراً كبيراً والضيافة كانت ممتازة. كل شيء كان منسقاً بإحكام. نتطلع للتعامل معكم مجدداً.",
    rating: 5,
    service: "ضيافة مؤتمرات",
  },
];

export const FAQS = [
  {
    question: "كيف يمكنني الحجز؟",
    answer: "يمكنك الحجز عبر تعبئة نموذج الطلب على الموقع أو الاتصال بنا مباشرة على واتساب. سنتواصل معك خلال 24 ساعة لتأكيد التفاصيل.",
  },
  {
    question: "ما هي مناطق التغطية؟",
    answer: "نخدم جميع مناطق سلطنة عمان من مسقط إلى صلالة. خدمتنا المتنقلة تصلك أينما كنت.",
  },
  {
    question: "هل يمكن تخصيص القائمة؟",
    answer: "نعم، يمكن تخصيص القائمة حسب رغبتك ونوع المناسبة. نقدم استشارة مجانية لمساعدتك في اختيار الأطباق المناسبة.",
  },
  {
    question: "كم يحتاج الحجز مقدماً؟",
    answer: "ننصح بالحجز قبل ٢-٣ أسابيع على الأقل، وقبل شهر في الموسم (شهر رمضان والأعياد) لضمان التوفر.",
  },
  {
    question: "هل تقدمون عينات للتذوق؟",
    answer: "نعم، نقدم جلسات تذوق للمناسبات الكبيرة (أكثر من ١٠٠ ضيف). يمكن تحديد موعد من خلال التواصل معنا.",
  },
  {
    question: "ما هي سياسة الإلغاء؟",
    answer: "يمكن الإلغاء مجاناً قبل أسبوع من الموعد. الإلغاء قبل ٤٨ ساعة يسترد ٥٠% من القيمة. الإلغاء قبل أقل من ٤٨ ساعة لا يسترد.",
  },
];

export const PORTFOLIO_ITEMS = [
  { id: 1, title: "حفل زفاف فاخر", image: "/images/portfolio-1.jpg", category: "wedding" },
  { id: 2, title: "مؤتمر الشركات", image: "/images/portfolio-2.jpg", category: "corporate" },
  { id: 3, title: "تنسيق طاولات ملكي", image: "/images/portfolio-3.jpg", category: "private" },
  { id: 4, title: "فعالية خاصة", image: "/images/portfolio-4.jpg", category: "private" },
  { id: 5, title: "ضيافة زفاف", image: "/images/service-wedding.jpg", category: "wedding" },
  { id: 6, title: "بوفيه مؤتمر", image: "/images/service-conference.jpg", category: "conference" },
  { id: 7, title: "ضيافة VIP", image: "/images/service-vip.jpg", category: "private" },
  { id: 8, title: "قهوة عربية", image: "/images/service-coffee.jpg", category: "coffee" },
];

export const STATS = [
  { value: 500, suffix: "+", label: "مناسبة ناجحة" },
  { value: 10, suffix: "+", label: "سنوات خبرة" },
  { value: 50, suffix: "+", label: "شريك موثوق" },
  { value: 100, suffix: "%", label: "رضا العملاء" },
];
